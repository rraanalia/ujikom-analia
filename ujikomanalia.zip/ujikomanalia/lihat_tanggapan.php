<!DOCTYPE html>
<html lang="en">

<body id="page-top">

    <div class="card shadow">
        <div class="card-header">
            Detail Pengaduan
        </div>
        <div class="card-body">
            <div class="form-group cols-sm-6">
                <a href="?url=lihat_pengaduan" class="btn btn-primary btn-icon-split">
                    <span class="icon text-white-50">
                        <i class="fas fa-arrow-left"></i>
                    </span>
                    <span class="text">Kembali</span>
                </a>
            </div>
            <form action="" method="POST" class="form-horizontal" enctype="multipart/form-data">
                <?php

                require 'koneksi.php';
                $sql = mysqli_query($koneksi, "SELECT * FROM pengaduan, tanggapan WHERE tanggapan.id_pengaduan='$_GET[id]' AND tanggapan.id_pengaduan=pengaduan.id_pengaduan");
                $cek = mysqli_num_rows($sql);
                if ($cek < 1) {
                    echo "<font color='red'>Pengaduan Belum Ditanggapi</font>";
                } else

                    if ($data = mysqli_fetch_array($sql)) {
                        ?>

                        <div class="form-group cols-sm-6">
                            <label>Tanggal Tanggapan</label>
                            <input type="text" name="tgl_pengaduan" value="<?php echo $data['tgl_tanggapan']; ?>"
                                class="form-control" readonly>
                        </div>

                        <div class="form-group cols-sm-6">
                            <label>Isi Laporan</label>
                            <textarea class="form-control" rows="7" name="isi_laporan"
                                readonly=""><?php echo $data['isi_laporan'] ?></textarea>
                        </div>

                        <div class="form-group cols-sm-6">
                            <label>Tanggapan</label>
                            <textarea class="form-control" rows="7" name="tanggapan"
                                readonly=""><?php echo $data['tanggapan'] ?></textarea>
                        </div>


                    <?php } ?>
            </form>

</body>

</html>