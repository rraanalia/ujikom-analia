<?php
include("css.php");
?>

<!DOCTYPE html>
<html lang="en">

<body id="page-top">

    <div class="card shadow">
        <div class="card-header">
            Tambah Petugas
        </div>

        <div class="card-body">
            <form action="simpan_petugas.php" method="POST" class="form-horizontal" enctype="multipart/form-data">
                <div class="form-group cols-sm-6">
                    <label>Nama Petugas</label>
                    <input type="text" name="nama_petugas" value="" class="form-control" required>
                </div>
                <div class="form-group cols-sm-6">
                    <label>Username</label>
                    <input type="text" name="username" value="" class="form-control" required>
                </div>
                <div class="form-group cols-sm-6">
                    <label>Password</label>
                    <input type="text" name="password" value="" class="form-control" required>
                </div>
                <div class="form-group cols-sm-6">
                    <label>Telp</label>
                    <input type="number" name="telp" value="" class="form-control" required>
                </div>
                <div class="form-group cols-sm-6">
                    <label>Level</label>
                    <select class="form-control" name="level">
                        <option>Pilih Level</option>
                        <option value="admin">Admin</option>
                        <option value="petugas">Petugas</option>
                    </select>
                </div>

                <div class="form-group col-sm-6"></div>
                <input type="submit" value="Simpan" class="btn btn-primary">
                <input type="reset" value="Kosongkan" class="btn btn-warning">

</body>

</html>